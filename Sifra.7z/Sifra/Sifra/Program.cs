﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sifra
{
    class Program
    {
        static void Main(string[] args)
        {
            string zprava = "POKUD HLEDATE POMOCNOU RUKU, NAJDETE JI NA KONCI SVE PAZE.";          
            Caesar(zprava, 7);
            Console.WriteLine();
            XOR(zprava, "PRAVDA");
            Console.ReadKey();
        }
        public static void Caesar(string zprava, int klic)
        {
            char[] zpravaChar = zprava.ToCharArray();
            char[] abeceda = new char[26] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            string sifra = "";
            for (int j = 0; j < zpravaChar.Length; j++)
            {
                for (int i = 0; i < abeceda.Length; i++)
                {
                    if (zpravaChar[j] == abeceda[i])
                    {
                        zpravaChar[j] = abeceda[(i + klic) % abeceda.Length];
                        break;
                    }
                }
            }
            sifra = new string(zpravaChar);

            Console.WriteLine("Caesarova sifra: " + sifra);

        }
        public static void XOR(string zprava, string klic)
        {
            string sifra2 = "";

            char[] zpravaChar = new char[zprava.Length];
            for (int i = 0; i < zprava.Length; i++)
            {

                char zpravapismeno = zprava[i];
                uint zpravaKod = (uint)zpravapismeno;
                int poziceKlice = i % klic.Length;
                char KlicPismeno = klic[poziceKlice];
                uint klicKod = (uint)KlicPismeno;
                uint XOR = zpravaKod ^ klicKod;
                char vysledek = (char)XOR;
                zpravaChar[i] = vysledek;


            }
            sifra2 = new string(zpravaChar);
            Console.WriteLine(sifra2);
        }
    }
}
